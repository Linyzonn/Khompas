# 🔍 Review complète de Khompas — juillet 2026

> Review du code v0.9 (lib/ + server/), croisée avec les retours d'expérience de prépa trouvés en ligne (Sherpas, Major Prépa, MyPrepa, Cours Thalès, ViragePrépa, fiche de M. Rigaut…) et la recherche en sciences cognitives sur l'apprentissage (Dunlosky et al. 2013, Hattie & Donoghue 2021, Bjork…). Sources en bas de fichier.

---

## 1. Vue d'ensemble

Khompas est déjà remarquablement bien pensé pour une bêta : le vocabulaire est le bon (khôlles, colloscope, semaines A/B, DM/DNS, 5/2, programmes de colles), le moteur est transparent et explicable, la boucle virale du code de classe est réelle, et la chaîne d'import IA est validée de bout en bout sur un vrai colloscope. C'est le cœur du founder-market fit et il est solide.

**Le diagnostic principal de cette review** : Khompas est aujourd'hui une excellente app d'*organisation* (quoi travailler, quand), mais elle ne dit presque rien sur *comment* travailler — alors que c'est là que la recherche est la plus claire et que la valeur perçue par un préparationnaire peut exploser. La bonne nouvelle : ton modèle de données (`Chapitre.maitrise`, `etape`, `dernierRevu`, les séances, les bilans) est déjà à 80 % prêt pour intégrer les deux techniques les plus efficaces connues — le **rappel actif** (se tester) et la **répétition espacée** — sans rien casser de la philosophie « moteur transparent ».

---

## 2. Ce qui est déjà très solide (à ne pas casser)

- **La règle d'or « cours vu aujourd'hui = revu ce soir »** (bonus ×1,5 dans le moteur) : c'est exactement ce que recommandent tous les anciens et les profs — et c'est de la répétition espacée J+0 sans le dire.
- **Le plan sur 2-3 matières par soirée** : c'est de l'interleaving léger, meilleur qu'une soirée mono-matière. Beaucoup d'élèves tombent dans le piège de sur-travailler la matière du prochain DS ; ton moteur, avec son « travail de fond » à 0,6, lutte déjà (partiellement) contre ça.
- **Les objectifs « jamais culpabilisants »** et la suggestion moyenne + 0,5 : posture rare et juste. Un objectif irréaliste démoralise — garde cette ligne partout (stats futures comprises).
- **L'écran de vérification obligatoire après import IA** : indispensable, bien fait (avertissements de l'IA remontés).
- **Le workflow chapitre en 5 étapes** (pas vu → vu en cours → revu → exos → DS passé) : c'est LE workflow prépa, et il est distinct de la maîtrise. Très bon design.
- **L'architecture générale** : moteur pur dans `engine.dart` (testable), modèles JSON simples, parseur IA tolérant avec plan B objet par objet, serveur async avec cache. Sain.

---

## 3. Bugs et risques techniques (par priorité)

### 🔴 P0 — risque de perte de données

**3.1 — `load()` peut effacer silencieusement toutes les données.** Dans `store.dart`, si `khompas.json` est corrompu (coupure pendant l'écriture, bug de version…), le `catch (_)` avale l'erreur, l'app démarre vide, et **le premier `save()` écrase le fichier corrompu avec un état vide** → semestre perdu. Fix simple :
- si le parse échoue, copier le fichier brut en `khompas.corrompu.json` AVANT tout ;
- poser un flag `chargementEchoue` et proposer à l'utilisateur « Restaurer une sauvegarde » plutôt que d'écraser au premier save ;
- (bonus) écrire d'abord dans `khompas.tmp` puis renommer — l'écriture devient atomique.

**3.2 — Le minuteur Pomodoro casse dès que l'écran se verrouille (iOS).** `Timer.periodic` avec `restant--` : quand l'app passe en arrière-plan ou que l'écran se verrouille, iOS suspend les timers → le décompte s'arrête, la tomate ne finit jamais, la séance n'est pas comptée. Fix :
- ne pas décrémenter : stocker un **horodatage de fin cible** (`DateTime finBloc`) et recalculer `restant = finBloc.difference(now)` à chaque tick (le temps « rattrape » à la reprise) ;
- ajouter `wakelock_plus` pour garder l'écran allumé pendant une séance (une ligne).

**3.3 — Synchro « last write wins » entre deux appareils.** Documenté, mais le scénario réel est : je coche 3 chapitres sur PC, mon téléphone (resté sur une vieille version) sauvegarde une modif anodine → push → écrase le travail du PC. Pour la bêta : au minimum, envoyer `exportedAt` du snapshot et **refuser côté serveur un push dont le snapshot est plus vieux que celui stocké** (avec un message « ton autre appareil a des données plus récentes — Récupère d'abord »). Le vrai merge par entité (un `updatedAt` par objet) peut attendre.

### 🟠 P1 — sécurité / justesse

**3.4 — Secret de compte stocké en clair dans Deno KV.** `server/main.ts` compare `acc.secret !== cle.slice(6)`. Si le KV fuit, toutes les clés fuient. Stocker `SHA-256(secret)` et comparer les hash (5 lignes avec `crypto.subtle.digest`). Idem : la clé API Anthropic côté app vit dans SharedPreferences en clair → `flutter_secure_storage` quand tu sortiras de la bêta.

**3.5 — Pas de coefficients sur les notes.** En prépa, quasiment tous les lycées coefficientent les DS (et parfois les khôlles comptent moitié). `moyenneDs`/`moyenneColles` font une moyenne simple → la moyenne affichée diverge de la vraie moyenne de classe, ce qui décrédibilise l'onglet Notes ET fausse les objectifs (moyenne + 0,5 calculée sur une base fausse). Ajouter `coeff` (défaut 1) sur `Ds` et `Colle`, et une pondération khôlles/DS par matière dans les réglages.

**3.6 — Priorités impossibles pour une matière présente uniquement dans l'EDT.** Réglages liste `m.matieres` (colles + DS + chapitres). En début d'année, avant tout import, les matières de l'emploi du temps n'y sont pas → on ne peut pas leur donner de priorité alors que le moteur les score. Inclure les matières des routines dans le getter `matieres` (ou un getter dédié pour l'écran).

**3.7 — Couleurs de matières potentiellement différentes entre web et téléphone.** `subjectColor` utilise `String.hashCode` pour les matières hors liste fixe — la valeur n'est pas garantie stable entre plateformes/versions de Dart. Remplacer par un petit hachage maison déterministe (djb2, 4 lignes).

**3.8 — RGPD léger mais réel.** Les photos de colloscope contiennent les **noms des khôlleurs** (données personnelles de tiers), stockées 13 mois côté serveur. Pour la bêta entre camarades ça passe, mais avant toute diffusion : page « données » claire, endpoint de suppression d'une classe par son créateur, et TTL plus court une fois l'extraction en cache (la photo n'est plus utile après).

### 🟡 P2 — dette et angles morts

- **Aucun test Dart.** Tu simules en Python (bien), mais `engine.dart` est une fonction pure — 10 tests `flutter test` dans le CI (le workflow fait déjà `flutter create .`) attraperaient les régressions du moteur à chaque push. C'est le meilleur ratio effort/sécurité du projet.
- **Purges agressives** : bilans et événements > 60 j, séances > 190 j. OK aujourd'hui, mais ça condamne les futures « stats de progression sur l'année » (roadmap). À décider avant de coder les stats, pas après.
- **Dédoublonnage des colles par matière + début** : si l'IA se trompe d'heure et qu'on ré-importe après correction, doublon. Acceptable, mais l'écran de vérification pourrait signaler « ressemble à une colle existante (même matière, même jour) ».

---

## 4. Le moteur « Ce soir » : limites précises et évolutions

Le moteur est bon, mais il a trois biais structurels :

**4.1 — Famine des matières sans échéances.** Français et LV, c'est 2-3 khôlles par an en scientifique — donc quasi jamais d'échéance dans l'horizon de 10 jours. Avec le score multiplicatif, elles ne remontent presque jamais… alors que le français est LA matière qui coule des candidats aux concours (gros coefficients, impossible à rattraper en 3 semaines). Les conseils d'anciens sont unanimes : étaler toutes les matières, ne pas travailler uniquement pour la prochaine échéance. Fix transparent, dans l'esprit du moteur :
- ajouter un facteur « **jachère** » : ×1 si la matière a été travaillée récemment (séances), montant progressivement jusqu'à ×2 après N jours sans séance ;
- et/ou garantir un mini-bloc hebdomadaire (15-20 min) pour chaque matière à priorité ≥ 2 non travaillée depuis 7 jours — parfait pour « 10 citations de français » ou « vocab d'anglais » (voir §6).

**4.2 — Les DM sont traités comme des deadlines, pas comme du travail long.** Le moteur ne voit un DM que quand la date de rendu approche → il encourage structurellement la procrastination. Le conseil de prof classique (fiche Rigaut) : **lire le DM le soir même de sa distribution**, et ne s'y mettre que par blocs sérieux de 30 min minimum. Fix : ajouter `dateDonne` au modèle `Devoir` → le soir de la distribution, le moteur insère « 📖 Lis le DM de X (15 min) — repère les parties » ; puis des blocs « avance le DM » répartis sur la période, pas seulement à J-2.
- Même logique pour les DS : la règle citée par les Sherpas est de ne jamais dépasser ~2,5× la durée du DS en préparation, mais **étalée en commençant ~2 semaines avant** — le moteur pourrait lisser la prépa d'un DS sur 10 jours au lieu de concentrer l'urgence sur les 2 derniers.

**4.3 — La fragilité moyenne masque les trous.** `fragilite` = moyenne de maîtrise des chapitres commencés : une matière avec 9 chapitres à 4 et un chapitre à 0 paraît saine (moy. 3,6) alors que le chapitre à 0 est exactement ce qui tombe au DS. Mixer moyenne et minimum, par ex. `fragilite = 1 + ((4 - avg)/4)*0.6 + ((4 - min)/4)*0.4`, et surtout : le contenu suggéré cible déjà les fragiles, mais le **chapitre à 0 devrait forcer une raison explicite** (« ⚠ Récurrences jamais consolidé »).

**4.4 — Mode révisions : bien, mais incomplet.**
- La rotation des chapitres est saine, mais les révisions de concours réelles sont largement pilotées par les **annales** (à garder pour cette période, pas avant, disent les anciens). Voir §7 (tracker d'annales).
- Blocs fixes de 60 min sur un seul chapitre : alterner 2 matières dans la soirée même en mode révisions (interleaving), et permettre des blocs 30 min pour les rappels rapides.
- **Après les écrits, l'app s'éteint** (`isBefore(dateConcours)`) alors que commence la période des oraux — planches, ADS, khôlles d'anglais… Tu viens de vivre un oral Mines-Télécom : c'est un mode entier qui manque (§7).

---

## 5. Passer un cap : la science de l'apprentissage dans Khompas

### 5.1 Ce que dit la recherche (en deux lignes)

La méta-analyse de référence (Dunlosky et al. 2013, répliquée par Hattie & Donoghue 2021 sur 242 études et ~169 000 participants) conclut que les deux techniques les plus efficaces sont **la pratique du test (rappel actif)** et **la pratique distribuée (espacement)** — et que relire, surligner et résumer, les stratégies par défaut des étudiants, sont parmi les moins efficaces car elles créent une **illusion de maîtrise** (fluence de relecture ≠ capacité de rappel — Bjork). Bonus important pour la prépa : la pratique du test **réduit l'anxiété d'examen** (Agarwal et al. 2014), au lieu de l'augmenter comme on le croit souvent.

Traduction prépa : la « feuille blanche » (refaire une démo/le plan du chapitre de mémoire), refaire un exercice sans le corrigé, se réciter le cours à l'écrit — ce que recommandent déjà tous les majors et les profs — c'est exactement du rappel actif. Khompas doit rendre ce comportement **par défaut**.

### 5.2 Répétition espacée intégrée au mode NORMAL (proposition concrète)

Aujourd'hui `dernierRevu` ne sert qu'en mode concours. Pendant l'année, la courbe de l'oubli fait son œuvre : un chapitre « revu chez moi » en octobre est mort en janvier, et l'app ne le voit pas. Proposition compatible avec ton modèle et ta philosophie « transparent » :

**Modèle** — ajouter à `Chapitre` :
```dart
DateTime? prochaineRevision;   // null = pas encore programmé
int intervalleJours;           // défaut 1
```

**Règles (simples, explicables — pas de SM-2 complet)** :
- Bilan « Cours » sur un chapitre → `prochaineRevision = demain`, `intervalleJours = 1` (ta règle d'or, formalisée).
- Quand une révision est cochée, l'app pose UNE question : « C'était comment ? 😮‍💨 Difficile · 🙂 Ça va · 😎 Facile » →
  - Difficile : `intervalleJours = 2` (on resserre) et maîtrise -1 proposée ;
  - Ça va : `intervalleJours ×= 2` ;
  - Facile : `intervalleJours ×= 2.5` et maîtrise +1 proposée ;
  - bornes [1, 45] jours, `prochaineRevision = aujourd'hui + intervalleJours`.
- C'est la « difficulté désirable » de Bjork en une question : un rappel ni trop facile ni trop dur est celui qui ancre le mieux.

**Moteur normal** — avant le scoring par matière, réserver un créneau « 🔁 Rappels du jour » : les 2-3 chapitres dont `prochaineRevision <= aujourd'hui`, en blocs de 10-15 min chacun, avec la consigne d'action (feuille blanche — voir 5.3). Le reste du temps suit la logique actuelle. En mode concours, les « dus » passent simplement en tête de la rotation existante.

Effet : sans rien changer d'autre, chaque chapitre revient à ~J+1, J+3, J+7, J+15, J+30… — le calendrier d'espacement que la recherche recommande, piloté par l'élève lui-même.

### 5.3 Rendre chaque suggestion ACTIONNABLE (rappel actif par défaut)

« Réviser : Récurrences linéaires » laisse l'élève choisir sa méthode — et la méthode par défaut de tout le monde, c'est relire. Chaque carte de suggestion devrait porter une **consigne d'action testable**, choisie selon matière × type de travail (bibliothèque en §6). Exemples :
- Revoir un cours de maths → « Feuille blanche 10 min : écris de mémoire les théorèmes + hypothèses du chapitre, puis compare au cours. Les trous = ton programme. »
- Préparer une khôlle de physique → « Refais les 2 démos types du programme SANS le cours, puis 1 exo type chrono. »
- Consolider un chapitre fragile → « Reprends un exo raté du TD : refais-le entièrement sans regarder ta correction. »

C'est ce que le workflow `etape` devrait exiger aussi : passer un chapitre en « revu chez moi » devrait sous-entendre « testé feuille blanche », pas « relu ». Un micro-texte d'aide suffit à installer la norme.

### 5.4 Casser l'illusion de maîtrise : relier les notes aux chapitres

`maitrise` est auto-déclarée — or l'auto-évaluation est notoirement mal calibrée (on se surestime après relecture). Tu as déjà les vraies données de calibration : **les notes**. Il manque juste le lien :
- à la saisie d'une note de khôlle/DS, proposer de cocher le(s) chapitre(s) concernés (tu as le programme de colle en texte — pré-cocher par correspondance de nom serait un plus) ;
- note < 8 sur un chapitre affiché maîtrise 3-4 → proposer gentiment de recalibrer (« Ta khôlle sur Récurrences s'est mal passée — on redescend la maîtrise à 2 ? ») ;
- ces liens nourrissent aussi le cahier d'erreurs (§7) et le mode révisions (les chapitres « plantés en DS » d'abord).

### 5.5 Pomodoro : adapter la taille des blocs à la matière

25/5 est parfait pour du vocabulaire ou des citations, mais fragmente la **recherche d'exercices** de maths/physique, qui demande de s'immerger (les profs conseillent 30 min minimum d'affilée rien que pour un DM). Suggestion : la méthode proposée par défaut dépend du contenu — résolution de problèmes → blocs 50/10 ou même 90 min ; rappels/langues → 25/5. Une simple heuristique sur le type de suggestion suffit.

### 5.6 Le sommeil est un outil de mémorisation, pas un luxe

Tous les retours d'anciens le disent : sacrifier le sommeil pour travailler plus est contre-productif (attention en berne le lendemain → il faut re-travailler ce qu'on a raté). Et la consolidation mémorielle se fait pendant le sommeil. Khompas peut l'incarner sans moraliser :
- réglage « heure limite » (ex. 23 h) : le plan du soir se tronque de lui-même (« Il te reste 40 min avant ton heure limite — on fait court : rappels du jour uniquement ») ;
- jamais de suggestion qui dépasse l'heure limite ; message positif à la coupure (« Le sommeil finit le travail : c'est là que ça s'imprime. »).

---

## 6. Bibliothèque de méthodes par matière (à afficher sous chaque suggestion)

L'idée : une table statique `methode(matiere, typeActivite)` → une phrase de consigne + une durée conseillée. Zéro IA, zéro serveur, très forte valeur perçue. Contenu proposé (synthèse des conseils de majors/profs + recherche) :

| Matière | Revoir le cours (rappel) | Exos / consolidation | Préparer khôlle | Préparer DS |
|---|---|---|---|---|
| **Maths** | Feuille blanche : théorèmes + hypothèses + définitions de mémoire, puis comparer. Refaire 1 démo clé sans le cours. | Chercher ≥ 10-15 min avant d'ouvrir le corrigé. Le lendemain, **refaire les exos ratés** (pas les réussis). Varier les types, ne pas refaire 10× le même. | Questions de cours à voix haute comme en colle + 2 exos types du programme, au tableau/brouillon debout si possible. | Un mini-DS chrono (1-2 exos d'annales de DS), puis relecture ciblée des erreurs. Commencer ~2 semaines avant, par petites touches. |
| **Physique** | Plan du chapitre de mémoire + « grands résultats » sous chaque partie ; refaire les démos types ; ordres de grandeur. Se réciter le cours **à l'écrit**. | Exos types d'abord (le satellite en trajectoire circulaire !), puis variations. Schématiser systématiquement. | Démos exigibles sans le cours + 1 exo type chrono. | Repérer les exos de TD qui font des « premières parties classiques » de DS et les refaire. |
| **Chimie** | Redessiner de mémoire mécanismes / diagrammes (E-pH, binaires…) — le dessin + le texte = double codage, ça ancre mieux. | Exos types par famille (dosages, cinétique…). | Mécanismes au tableau + questions de cours. | Fiches de mécanismes revues en rappel espacé les jours précédents. |
| **SII** | Schémas-blocs et méthodes types de mémoire ; refaire les schémas cinématiques. | Un problème complet plutôt que des morceaux. | Méthodes types du programme au brouillon. | Annales de DS du lycée si disponibles. |
| **Info** | Réécrire les algos du cours de zéro (pas relire le code). | Tracer à la main l'exécution sur un petit exemple. | Questions de cours + un algo au tableau. | Refaire les TP clés sans la correction. |
| **Anglais / LV** | 10-15 min par jour valent mieux qu'1 h le dimanche : l'espacement est encore plus rentable pour les langues. | Vocabulaire en rappel espacé (paquets de 10-20 mots) + 1 article de presse résumé oralement. | Press review chrono : lire → synthèse orale 3 min → opinion. S'enregistrer. | Essais types + relecture des erreurs de grammaire récurrentes. |
| **Français-philo** | Fiches œuvres du thème de l'année ; **citations en rappel espacé** (2-3 par jour, la régularité fait tout). | Plans détaillés en 20 min sur des sujets d'annales (sans rédiger). | Lecture + résumé chronométré. | 1 dissertation complète par période + plans détaillés en série. |

À terme, ces consignes deviennent des « recettes » cochables dans le mode checklist (chaque étape de la consigne = une case), et la matière détermine la taille des blocs Pomodoro (§5.5).

---

## 7. Fonctionnalités à ajouter (besoins prépa réels, par priorité)

### 🔴 P0 — le cap « science de l'apprentissage » (§5, résumé)
1. **Répétition espacée en mode normal** (`prochaineRevision` + auto-éval en 1 tap) — le plus gros levier du projet.
2. **Consignes d'action par suggestion** (bibliothèque §6) — faible effort, forte valeur.
3. **Lien notes ↔ chapitres** + recalibrage de maîtrise — casse l'illusion de maîtrise avec des données que tu as déjà.
4. **Coefficients de notes** (§3.5) — crédibilité de l'onglet Notes.

### 🟠 P1 — les manques prépa criants
5. **📕 Cahier d'erreurs** — LE classique des majors, absent de l'app. Modèle : `Erreur {matiere, chapitreId?, texte, source (DS/khôlle/DM), date, reglee}`. Saisie proposée au moment où on entre une note (« 2-3 erreurs à ne pas refaire ? ») ; ressortent automatiquement : avant un DS de la matière (« Relis tes 6 dernières erreurs de Maths — 5 min »), en mode révisions, et sur la fiche du chapitre. C'est du rappel actif ciblé sur ses propres failles — imbattable en ratio temps/points gagnés.
6. **🗣️ Mode ORAUX** — après les écrits, l'app doit vivre au lieu de s'éteindre : date des oraux par école, **planches chronométrées** (réutilise le minuteur : préparation 20-30 min + passage), rotation des matières d'oral, suivi anglais (press reviews), ADS pour les concernés. Tu viens de passer un oral Mines-Télécom : tu sais exactement ce qui aurait aidé.
7. **📚 Tracker d'annales (mode révisions)** — les révisions réelles sont pilotées par les annales (à cette période seulement). Liste par concours (X-ENS, Mines, Centrale, CCINP, e3a…) × matière × année, statut fait/à refaire + note ressentie ; le mode révisions alterne rotation de chapitres et blocs annales, et les chapitres plantés en annale remontent dans la rotation.
8. **🧪 Générateur de questions de cours via ton pipeline IA existant** — même mécanique que le colloscope : photo du chapitre → prompt copier-coller → JSON de questions de cours (définitions, théorèmes avec hypothèses, démos exigibles) → deck de flashcards révisées en espacement dans l'app. Les questions de cours ouvrent chaque khôlle et chaque DS : c'est l'usage d'Anki en prépa, mais intégré à ton système de chapitres. Gratuit pour l'utilisateur, réutilise `_objetsJson`.
9. **🔔 Notifications locales** — `flutter_local_notifications` marche en sideload (pas de push serveur nécessaire) : « Khôlle demain 18 h avec Mme Marié (salle 12) », « Ton plan du soir est prêt », rappel des DM à J-3. C'est LE levier de rétention quotidienne ; l'export .ics reste le complément calendrier.
10. **📥 Anticipation des DM** (`dateDonne`, §4.2) et lissage de la prépa des DS sur ~2 semaines.
11. **🧭 TIPE** — gros morceau du temps d'un PSI, invisible dans l'app : jalons officiels (MCOT, DOT, présentation), compteur d'heures TIPE, et une « matière » TIPE que le moteur peut planifier si une priorité lui est donnée.

### 🟡 P2 — confort, rétention, croissance
12. **Bilan hebdo guidé du dimanche (10 min)** : la semaine qui vient (khôlles/DS/DM affichés), 3 questions de métacognition (« Quelle matière a le plus souffert ? »), validation des priorités → planning hebdomadaire, l'outil n°1 des conseils d'organisation, mais généré au lieu d'être rempli à la main.
13. **Stats bienveillantes** : progression de la maîtrise par matière dans le temps, régularité (jours travaillés), corrélation douce travail ↔ notes. Toujours formulées en positif (ta ligne actuelle) ; attention aux purges 60/190 j qui limitent l'historique (§3).
14. **Partage des programmes de colle par le code de classe** : tu avais écarté la feature car les canaux étaient peu fiables — mais justement, ton infra de classe a changé la donne : UN élève colle le programme de la semaine → tous les groupes de la classe l'ont sur leur créneau. Même boucle virale que le colloscope, coût serveur quasi nul (texte).
15. **Charge de la semaine à venir** : petit indicateur (nb d'échéances pondéré) sur la vue semaine, pour matérialiser « la semaine prochaine est chargée, avance ce week-end » — l'anticipation est le conseil n°1 des anciens.
16. **Heure limite / garde-fou sommeil** (§5.6).
17. Widgets iOS/Android (post-sideload), et à terme mode hors-ligne robuste + merge de synchro par entité.

---

## 8. Si tu ne fais que 3 choses

1. **Corrige les deux bugs P0** (perte de données au chargement corrompu, minuteur qui meurt à l'écran verrouillé) — une soirée, et l'app devient digne de confiance.
2. **Ajoute la répétition espacée + l'auto-éval en 1 tap + les consignes d'action** — c'est le passage de « to-do list de prépa » à « coach qui applique ce que la science sait de l'apprentissage », et ça ne demande ni serveur ni IA.
3. **Cahier d'erreurs lié aux notes et aux chapitres** — la feature dont chaque ancien te dira « j'aurais dû faire ça », parfaitement dans l'ADN de l'app.

---

## 📚 Sources

**Sciences de l'apprentissage**
- Dunlosky et al. (2013), *Improving Students' Learning With Effective Learning Techniques* — practice testing et distributed practice en tête ; relecture/surlignage peu efficaces.
- Hattie & Donoghue (2021), *A Meta-Analysis of Ten Learning Techniques* (Frontiers in Education) — réplication : 242 études, ~169 000 participants. https://www.frontiersin.org/journals/education/articles/10.3389/feduc.2021.581216/full
- Agarwal et al. (2014) — la pratique du test en classe réduit l'anxiété d'examen. Voir synthèse : https://evidencebased.education/resource/retrieval-and-spaced-practice-study-strategies-that-must-be-combined/
- Bjork & Bjork — *desirable difficulties*, illusion de fluence ; le succès de rappel ne doit être ni trop haut ni trop bas.
- Revue sur les plateformes de rappel espacé (dual coding, interleaving, schémas) : https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7550004/

**Expérience prépa**
- Les Sherpas — planning de travail (ne pas travailler que pour la prochaine échéance, règle des 2,5× la durée du DS, anticiper 2 semaines) : https://sherpas.com/blog/planning-de-travail-prepa-scientifique/ ; khôlles : https://sherpas.com/blog/kholles-prepa-scientifique/ ; physique (feuille blanche « juge de paix », ~20 exos/chapitre) : https://sherpas.com/blog/travailler-physique-prepa-scientifique/
- Fiche « Optimiser le travail en prépa » de M. Rigaut (prof de physique) — DM lu le soir même, blocs ≥ 30 min : http://www.matthieurigaut.net/public/docs/conseils_travail.pdf
- Major Prépa — réviser la physique (plan du chapitre de mémoire, cours du jour le soir même, définitions) : https://major-prepa.com/physique-chimie/comment-reviser-efficacement-physique-prepa-mpsi-pcsi/
- MyPrepa — feuille blanche par sous-partie : https://myprepa.fr/blog/methodologie-comment-reviser-et-maitriser-son-cours-de-physique/
- Excellence Maths — révision active vs passive, test de la page blanche : https://www.excellence-maths.fr/ressource/methode-travail-maths-sup-guide/
- Cours Thalès — organisation, sommeil : https://www.cours-thales.fr/prepas-scientifiques/comment-bien-s-organiser-en-prepa/
- ViragePrépa — régularité > volume, annales à garder pour la période de concours : https://www.virageprepa.com/articles/
